package com.myledger.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Iterator;

public class MainActivity extends Activity {

    private static final int NOTIFICATION_PERMISSION_REQUEST = 1001;
    static final String CHANNEL_ID = "myledger_bill_reminders";
    private static final String PREFS = "myledger_reminders";
    private static final String REMINDERS_JSON = "reminders";
    private WebView webView;
    private String currentTab = "home";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createNotificationChannel();
        createInvestmentNotificationChannel();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new LedgerBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onBackPressed() {
        if (!"home".equals(currentTab)) {
            currentTab = "home";
            if (webView != null) {
                webView.evaluateJavascript("if(window.__switchToHome){window.__switchToHome();}", null);
            }
            return;
        }
        super.onBackPressed();
    }

    public void setCurrentTab(String tab) {
        if (tab != null && !tab.isEmpty()) currentTab = tab;
    }

    public void requestBillNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    public void scheduleBillReminder(String name, double amount, String currency, int dueDay) {
        if (name == null || name.trim().isEmpty() || dueDay < 1 || dueDay > 31) return;
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(REMINDERS_JSON, "[]"));
            JSONArray out = new JSONArray();
            boolean replaced = false;

            for (int i = 0; i < old.length(); i++) {
                JSONObject item = old.optJSONObject(i);
                if (item == null) continue;
                if (name.equals(item.optString("name"))) {
                    JSONObject replacement = new JSONObject();
                    replacement.put("name", name);
                    replacement.put("amount", amount);
                    replacement.put("currency", currency == null ? "" : currency);
                    replacement.put("dueDay", dueDay);
                    out.put(replacement);
                    replaced = true;
                } else {
                    out.put(item);
                }
            }
            if (!replaced) {
                JSONObject item = new JSONObject();
                item.put("name", name);
                item.put("amount", amount);
                item.put("currency", currency == null ? "" : currency);
                item.put("dueDay", dueDay);
                out.put(item);
            }
            sp.edit().putString(REMINDERS_JSON, out.toString()).apply();
            BillReminderReceiver.schedule(this, name, amount, currency, dueDay);
        } catch (Exception ignored) {
        }
    }

    public void cancelBillReminder(String name) {
        if (name == null || name.isEmpty()) return;
        BillReminderReceiver.cancel(this, name);
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(REMINDERS_JSON, "[]"));
            JSONArray out = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject item = old.optJSONObject(i);
                if (item != null && !name.equals(item.optString("name"))) out.put(item);
            }
            sp.edit().putString(REMINDERS_JSON, out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public void rescheduleSavedReminders() {
        try {
            JSONArray items = new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(REMINDERS_JSON, "[]"));
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                BillReminderReceiver.schedule(
                        this,
                        item.optString("name"),
                        item.optDouble("amount", 0),
                        item.optString("currency"),
                        item.optInt("dueDay", 0)
                );
            }
        } catch (Exception ignored) {
        }
    }

    private void createInvestmentNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("myledger_investment_reminders", "Investment updates", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Automatic investment transaction updates");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Bill & EMI reminders",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Credit card and EMI due-date reminders");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    public static class LedgerBridge {
        private final MainActivity activity;
        LedgerBridge(MainActivity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public void setCurrentTab(String tab) {
            activity.setCurrentTab(tab);
        }

        @JavascriptInterface
        public void requestBillNotifications() {
            activity.requestBillNotifications();
        }

        @JavascriptInterface
        public void scheduleBillReminder(String name, double amount, String currency, int dueDay) {
            activity.runOnUiThread(() -> activity.scheduleBillReminder(name, amount, currency, dueDay));
        }

        @JavascriptInterface
        public void cancelBillReminder(String name) {
            activity.runOnUiThread(() -> activity.cancelBillReminder(name));
        }

        @JavascriptInterface
        public void scheduleInvestment(String id, String name, double amount, String account, String currency, String frequency, String startDate, String category) {
            activity.runOnUiThread(() -> InvestmentReceiver.schedule(activity, id, name, amount, account, currency, frequency, startDate, category));
        }

        @JavascriptInterface
        public void cancelInvestment(String id) {
            activity.runOnUiThread(() -> InvestmentReceiver.cancel(activity, id));
        }

        @JavascriptInterface
        public String getPendingInvestments() { return InvestmentReceiver.getPending(activity); }

        @JavascriptInterface
        public void clearPendingInvestments() { activity.runOnUiThread(() -> InvestmentReceiver.clearPending(activity)); }
    }
}
