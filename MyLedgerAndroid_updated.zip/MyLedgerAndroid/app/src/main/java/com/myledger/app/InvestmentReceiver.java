package com.myledger.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class InvestmentReceiver extends BroadcastReceiver {
    private static final String ACTION = "com.myledger.app.INVESTMENT_DUE";
    private static final String PREFS = "myledger_investments_native";
    private static final String PLANS = "plans";
    private static final String PENDING = "pending";
    private static final String CHANNEL_ID = "myledger_investment_reminders";

    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            rescheduleAll(context); return;
        }
        if (!ACTION.equals(intent.getAction())) return;
        String id=intent.getStringExtra("id"), name=intent.getStringExtra("name"), account=intent.getStringExtra("account");
        double amount=intent.getDoubleExtra("amount",0); String currency=intent.getStringExtra("currency");
        String frequency=intent.getStringExtra("frequency"), category=intent.getStringExtra("category");
        postPending(context, id, name, amount, account, currency, category);
        try { schedule(context,id,name,amount,account,currency,frequency,intent.getStringExtra("startDate"),category); } catch(Exception ignored){}
    }

    /** Writes one pending investment entry and shows the notification, exactly like a
     *  real alarm firing would. Used both by the real 9am alarm and by the "Test debit
     *  now" button in investment details, so testing exercises the same code path as
     *  production instead of a separate shortcut. */
    public static void postPending(Context context, String id, String name, double amount, String account, String currency, String category){
        String date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        try {
            SharedPreferences sp=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
            JSONArray pending=new JSONArray(sp.getString(PENDING,"[]"));
            JSONObject item=new JSONObject(); item.put("investmentId",id); item.put("name",name); item.put("account",account);
            item.put("amount",amount); item.put("currency",currency==null?"":currency); item.put("category",category==null?"Investment":category); item.put("date",date);
            pending.put(item); sp.edit().putString(PENDING,pending.toString()).apply();
            showNotification(context,name,amount,currency);
        } catch(Exception ignored){}
    }

    public static void schedule(Context context,String id,String name,double amount,String account,String currency,String frequency,String startDate,String category){
        if(id==null||id.isEmpty()||amount<=0||frequency==null) return;
        try{
            Calendar now=Calendar.getInstance(); Calendar when=Calendar.getInstance(); when.set(Calendar.SECOND,0); when.set(Calendar.MILLISECOND,0); when.set(Calendar.HOUR_OF_DAY,9); when.set(Calendar.MINUTE,0);
            Calendar start=Calendar.getInstance();
            if(startDate!=null&&!startDate.isEmpty()){
                Date parsed=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(startDate); if(parsed!=null) start.setTime(parsed);
            }
            start.set(Calendar.HOUR_OF_DAY,9); start.set(Calendar.MINUTE,0); start.set(Calendar.SECOND,0); start.set(Calendar.MILLISECOND,0);
            when.setTimeInMillis(start.getTimeInMillis());
            while(!when.after(now)) advance(when,frequency);
            Intent i=new Intent(context,InvestmentReceiver.class); i.setAction(ACTION); i.putExtra("id",id); i.putExtra("name",name); i.putExtra("amount",amount); i.putExtra("account",account); i.putExtra("currency",currency==null?"":currency); i.putExtra("frequency",frequency); i.putExtra("startDate",startDate==null?"":startDate); i.putExtra("category",category==null?"Investment":category);
            PendingIntent pi=PendingIntent.getBroadcast(context,requestCode(id),i,flags()); AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE); if(am==null)return;
            if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi); else am.set(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi);
            savePlan(context,id,name,amount,account,currency,frequency,startDate,category);
        }catch(Exception ignored){}
    }
    private static void advance(Calendar c,String f){ if("daily".equals(f))c.add(Calendar.DAY_OF_YEAR,1); else if("weekly".equals(f))c.add(Calendar.DAY_OF_YEAR,7); else c.add(Calendar.MONTH,1); }
    private static void savePlan(Context c,String id,String name,double amount,String account,String currency,String frequency,String startDate,String category)throws Exception{
        SharedPreferences sp=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE); JSONArray old=new JSONArray(sp.getString(PLANS,"[]")), out=new JSONArray(); boolean found=false;
        for(int n=0;n<old.length();n++){JSONObject o=old.optJSONObject(n); if(o==null)continue; if(id.equals(o.optString("id"))){found=true; o=new JSONObject();o.put("id",id);o.put("name",name);o.put("amount",amount);o.put("account",account);o.put("currency",currency==null?"":currency);o.put("frequency",frequency);o.put("startDate",startDate==null?"":startDate);o.put("category",category==null?"Investment":category);} out.put(o);}
        if(!found){JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("amount",amount);o.put("account",account);o.put("currency",currency==null?"":currency);o.put("frequency",frequency);o.put("startDate",startDate==null?"":startDate);o.put("category",category==null?"Investment":category);out.put(o);} sp.edit().putString(PLANS,out.toString()).apply();
    }
    public static void cancel(Context c,String id){if(id==null)return; Intent i=new Intent(c,InvestmentReceiver.class);i.setAction(ACTION);PendingIntent pi=PendingIntent.getBroadcast(c,requestCode(id),i,flags());AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pi);pi.cancel();try{SharedPreferences sp=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);JSONArray old=new JSONArray(sp.getString(PLANS,"[]")),out=new JSONArray();for(int n=0;n<old.length();n++){JSONObject o=old.optJSONObject(n);if(o!=null&&!id.equals(o.optString("id")))out.put(o);}sp.edit().putString(PLANS,out.toString()).apply();}catch(Exception ignored){}}
    public static void rescheduleAll(Context c){try{JSONArray a=new JSONArray(c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(PLANS,"[]"));for(int n=0;n<a.length();n++){JSONObject o=a.optJSONObject(n);if(o!=null)schedule(c,o.optString("id"),o.optString("name"),o.optDouble("amount"),o.optString("account"),o.optString("currency"),o.optString("frequency"),o.optString("startDate"),o.optString("category"));}}catch(Exception ignored){}}
    public static String getPending(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(PENDING,"[]");}
    public static void clearPending(Context c){c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(PENDING,"[]").apply();}
    private static int requestCode(String s){return 500000+Math.abs((s==null?"":s).hashCode()%100000);}
    private static int flags(){return PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0);}
    private static void showNotification(Context c,String name,double amount,String currency){NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm==null)return;Intent open=new Intent(c,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);PendingIntent pi=PendingIntent.getActivity(c,requestCode(name)+200000,open,flags());String money=(currency==null?"":currency)+" "+String.format(Locale.US,"%.2f",amount);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL_ID):new Notification.Builder(c);Notification n=b.setSmallIcon(com.myledger.app.R.mipmap.ic_launcher).setContentTitle("Investment posted").setContentText(name+" • "+money).setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_DEFAULT).build();if(Build.VERSION.SDK_INT<33||c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED)nm.notify(requestCode(name)+300000,n);}
}
