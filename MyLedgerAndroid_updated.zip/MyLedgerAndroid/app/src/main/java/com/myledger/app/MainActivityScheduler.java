package com.myledger.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

public final class MainActivityScheduler {
    private static final String PREFS = "myledger_reminders";
    private static final String REMINDERS_JSON = "reminders";

    private MainActivityScheduler() {}

    public static void rescheduleAll(Context context) {
        try {
            SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray items = new JSONArray(sp.getString(REMINDERS_JSON, "[]"));
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                BillReminderReceiver.schedule(
                        context,
                        item.optString("name"),
                        item.optDouble("amount", 0),
                        item.optString("currency"),
                        item.optInt("dueDay", 0)
                );
            }
        } catch (Exception ignored) {}
    }
}
