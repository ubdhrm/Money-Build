package com.myledger.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;


import java.util.Calendar;

public class BillReminderReceiver extends BroadcastReceiver {

    private static final String ACTION_BILL = "com.myledger.app.BILL_REMINDER";
    private static final String ACTION_BILL_UPCOMING = "com.myledger.app.BILL_REMINDER_UPCOMING";
    private static final int UPCOMING_DAYS_BEFORE = 3;
    private static final String CHANNEL_ID = "myledger_bill_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            MainActivityScheduler.rescheduleAll(context);
            return;
        }

        boolean isUpcoming = ACTION_BILL_UPCOMING.equals(intent.getAction());
        if (!ACTION_BILL.equals(intent.getAction()) && !isUpcoming) return;

        String name = intent.getStringExtra("name");
        double amount = intent.getDoubleExtra("amount", 0);
        String currency = intent.getStringExtra("currency");
        int dueDay = intent.getIntExtra("dueDay", 0);

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                requestCode(name) + 100000,
                open,
                pendingFlags()
        );

        boolean hasAmountDue = amount > 0;
        String money = (currency == null ? "" : currency) + " " + formatAmount(amount);
        String title, shortText, longText;
        if (isUpcoming) {
            title = "Bill / EMI due in " + UPCOMING_DAYS_BEFORE + " days";
            shortText = hasAmountDue ? money : ("Due in " + UPCOMING_DAYS_BEFORE + " days");
            longText = hasAmountDue
                    ? (name + " is due in " + UPCOMING_DAYS_BEFORE + " days. Amount: " + money)
                    : (name + "'s due date is in " + UPCOMING_DAYS_BEFORE + " days.");
        } else {
            title = hasAmountDue ? "Bill / EMI due today" : "Bill due date today";
            shortText = hasAmountDue ? money : "Nothing due right now";
            longText = hasAmountDue
                    ? (name + " is due today. Amount: " + money)
                    : (name + "'s due date is today, but nothing is currently owed.");
        }
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        Notification notification = nb
                .setSmallIcon(com.myledger.app.R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(name + " • " + shortText)
                .setStyle(new Notification.BigTextStyle().bigText(longText))
                .setPriority(hasAmountDue ? Notification.PRIORITY_HIGH : Notification.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .build();

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        int notifyId = isUpcoming ? (requestCode(name) + 700000) : requestCode(name);
        if (nm != null && (Build.VERSION.SDK_INT < 33 ||
                context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
                        android.content.pm.PackageManager.PERMISSION_GRANTED)) {
            nm.notify(notifyId, notification);
        }

        if (!isUpcoming && dueDay >= 1 && dueDay <= 31) {
            schedule(context, name, amount, currency, dueDay);
        }
    }

    public static void schedule(Context context, String name, double amount, String currency, int dueDay) {
        if (name == null || name.isEmpty() || dueDay < 1 || dueDay > 31) return;

        Calendar now = Calendar.getInstance();
        Calendar when = Calendar.getInstance();
        when.set(Calendar.SECOND, 0);
        when.set(Calendar.MILLISECOND, 0);
        when.set(Calendar.HOUR_OF_DAY, 9);
        when.set(Calendar.MINUTE, 0);
        when.set(Calendar.DAY_OF_MONTH, Math.min(dueDay, when.getActualMaximum(Calendar.DAY_OF_MONTH)));

        if (!when.after(now)) {
            when.add(Calendar.MONTH, 1);
            when.set(Calendar.DAY_OF_MONTH, Math.min(dueDay, when.getActualMaximum(Calendar.DAY_OF_MONTH)));
        }

        Intent intent = new Intent(context, BillReminderReceiver.class);
        intent.setAction(ACTION_BILL);
        intent.putExtra("name", name);
        intent.putExtra("amount", amount);
        intent.putExtra("currency", currency == null ? "" : currency);
        intent.putExtra("dueDay", dueDay);

        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                requestCode(name),
                intent,
                pendingFlags()
        );

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        if (Build.VERSION.SDK_INT >= 23) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        } else {
            am.set(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
        }

        // Extra heads-up reminder a few days before the due date.
        Calendar upcoming = (Calendar) when.clone();
        upcoming.add(Calendar.DAY_OF_YEAR, -UPCOMING_DAYS_BEFORE);
        PendingIntent upcomingPi = PendingIntent.getBroadcast(
                context,
                upcomingRequestCode(name),
                upcomingIntent(context, name, amount, currency, dueDay),
                pendingFlags()
        );
        if (upcoming.after(Calendar.getInstance())) {
            if (Build.VERSION.SDK_INT >= 23) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, upcoming.getTimeInMillis(), upcomingPi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, upcoming.getTimeInMillis(), upcomingPi);
            }
        } else {
            am.cancel(upcomingPi);
        }
    }

    private static Intent upcomingIntent(Context context, String name, double amount, String currency, int dueDay) {
        Intent intent = new Intent(context, BillReminderReceiver.class);
        intent.setAction(ACTION_BILL_UPCOMING);
        intent.putExtra("name", name);
        intent.putExtra("amount", amount);
        intent.putExtra("currency", currency == null ? "" : currency);
        intent.putExtra("dueDay", dueDay);
        return intent;
    }

    public static void cancel(Context context, String name) {
        Intent intent = new Intent(context, BillReminderReceiver.class);
        intent.setAction(ACTION_BILL);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, requestCode(name), intent, pendingFlags()
        );
        PendingIntent upcomingPi = PendingIntent.getBroadcast(
                context, upcomingRequestCode(name), upcomingIntent(context, name, 0, "", 0), pendingFlags()
        );
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) { am.cancel(pi); am.cancel(upcomingPi); }
        pi.cancel();
        upcomingPi.cancel();
    }

    private static int requestCode(String name) {
        return Math.abs((name == null ? "" : name).hashCode());
    }

    private static int upcomingRequestCode(String name) {
        return requestCode(name) + 600000;
    }

    private static int pendingFlags() {
        return PendingIntent.FLAG_UPDATE_CURRENT |
                (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    private static String formatAmount(double amount) {
        if (Math.abs(amount - Math.rint(amount)) < 0.0001) {
            return String.format(java.util.Locale.US, "%.0f", amount);
        }
        return String.format(java.util.Locale.US, "%.2f", amount);
    }
}
