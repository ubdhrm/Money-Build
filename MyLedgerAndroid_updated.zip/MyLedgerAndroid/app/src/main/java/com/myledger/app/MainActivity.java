package com.myledger.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Iterator;

public class MainActivity extends Activity {

    private static final int NOTIFICATION_PERMISSION_REQUEST = 1001;
    static final String CHANNEL_ID = "myledger_bill_reminders";
    private static final String PREFS = "myledger_reminders";
    private static final String REMINDERS_JSON = "reminders";
    private WebView webView;
    private String currentTab = "home";
    private boolean detailOpen = false;

    @Override
    protected void onResume() {
        super.onResume();
        // The WebView/JS keeps running while the app is only backgrounded (not
        // killed), so index.html's one-time startup import never re-fires on
        // its own. Re-run it here so anything that posted while the app was in
        // the background (or just sitting on the home screen) shows up as soon
        // as the user comes back in, instead of only after a full relaunch.
        if (webView != null) {
            webView.evaluateJavascript("if(window.myLedgerRefresh){window.myLedgerRefresh();}", null);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createNotificationChannel();
        createInvestmentNotificationChannel();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.confirm())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .setCancelable(true)
                        .show();
                return true;
            }
        });
        webView.addJavascriptInterface(new LedgerBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onBackPressed() {
        if (detailOpen) {
            detailOpen = false;
            if (webView != null) {
                webView.evaluateJavascript("if(window.__closeDetailModal){window.__closeDetailModal();}", null);
            }
            return;
        }
        if (!"home".equals(currentTab)) {
            currentTab = "home";
            if (webView != null) {
                webView.evaluateJavascript("if(window.__switchToHome){window.__switchToHome();}", null);
            }
            return;
        }
        super.onBackPressed();
    }

    public void setCurrentTab(String tab) {
        if (tab != null && !tab.isEmpty()) currentTab = tab;
    }

    public void setDetailOpen(boolean open) {
        detailOpen = open;
    }

    public void requestBillNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    public void scheduleBillReminder(String name, double amount, String currency, int dueDay) {
        if (name == null || name.trim().isEmpty() || dueDay < 1 || dueDay > 31) return;
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(REMINDERS_JSON, "[]"));
            JSONArray out = new JSONArray();
            boolean replaced = false;

            for (int i = 0; i < old.length(); i++) {
                JSONObject item = old.optJSONObject(i);
                if (item == null) continue;
                if (name.equals(item.optString("name"))) {
                    JSONObject replacement = new JSONObject();
                    replacement.put("name", name);
                    replacement.put("amount", amount);
                    replacement.put("currency", currency == null ? "" : currency);
                    replacement.put("dueDay", dueDay);
                    out.put(replacement);
                    replaced = true;
                } else {
                    out.put(item);
                }
            }
            if (!replaced) {
                JSONObject item = new JSONObject();
                item.put("name", name);
                item.put("amount", amount);
                item.put("currency", currency == null ? "" : currency);
                item.put("dueDay", dueDay);
                out.put(item);
            }
            sp.edit().putString(REMINDERS_JSON, out.toString()).apply();
            BillReminderReceiver.schedule(this, name, amount, currency, dueDay);
        } catch (Exception ignored) {
        }
    }

    public void cancelBillReminder(String name) {
        if (name == null || name.isEmpty()) return;
        BillReminderReceiver.cancel(this, name);
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(REMINDERS_JSON, "[]"));
            JSONArray out = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject item = old.optJSONObject(i);
                if (item != null && !name.equals(item.optString("name"))) out.put(item);
            }
            sp.edit().putString(REMINDERS_JSON, out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public void rescheduleSavedReminders() {
        try {
            JSONArray items = new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(REMINDERS_JSON, "[]"));
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                BillReminderReceiver.schedule(
                        this,
                        item.optString("name"),
                        item.optDouble("amount", 0),
                        item.optString("currency"),
                        item.optInt("dueDay", 0)
                );
            }
        } catch (Exception ignored) {
        }
    }

    public int getAppVersionCode() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionCode;
        } catch (Exception e) {
            return -1;
        }
    }

    public void openUrl(String url) {
        if (url == null || url.trim().isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) {
        }
    }

    private void createInvestmentNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("myledger_investment_reminders", "Investment updates", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Automatic investment transaction updates");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Bill & EMI reminders",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Credit card and EMI due-date reminders");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    public static class LedgerBridge {
        private final MainActivity activity;
        LedgerBridge(MainActivity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public void setCurrentTab(String tab) {
            activity.setCurrentTab(tab);
        }

        @JavascriptInterface
        public void setDetailOpen(boolean open) {
            activity.runOnUiThread(() -> activity.setDetailOpen(open));
        }

        @JavascriptInterface
        public void requestBillNotifications() {
            activity.runOnUiThread(activity::requestBillNotifications);
        }

        @JavascriptInterface
        public void scheduleBillReminder(String name, double amount, String currency, int dueDay) {
            activity.runOnUiThread(() -> activity.scheduleBillReminder(name, amount, currency, dueDay));
        }

        @JavascriptInterface
        public void cancelBillReminder(String name) {
            activity.runOnUiThread(() -> activity.cancelBillReminder(name));
        }

        @JavascriptInterface
        public void scheduleInvestment(String id, String name, double amount, String account, String currency, String frequency, String startDate, String category) {
            activity.runOnUiThread(() -> InvestmentReceiver.schedule(activity, id, name, amount, account, currency, frequency, startDate, category));
        }

        @JavascriptInterface
        public void cancelInvestment(String id) {
            activity.runOnUiThread(() -> InvestmentReceiver.cancel(activity, id));
        }

        @JavascriptInterface
        public int getAppVersionCode() { return activity.getAppVersionCode(); }

        @JavascriptInterface
        public void openUrl(String url) {
            activity.runOnUiThread(() -> activity.openUrl(url));
        }

        @JavascriptInterface
        public String getPendingInvestments() { return InvestmentReceiver.getPending(activity); }

        @JavascriptInterface
        public void clearPendingInvestments() { activity.runOnUiThread(() -> InvestmentReceiver.clearPending(activity)); }

        // Debug/testing only: posts one investment cycle right now, using the exact
        // same pending-write + notification code the real 9am alarm uses — so you can
        // verify the whole auto-debit pipeline works without waiting for the clock.
        @JavascriptInterface
        public void testInvestmentNow(String id, String name, double amount, String account, String currency, String category) {
            activity.runOnUiThread(() -> InvestmentReceiver.postPending(activity, id, name, amount, account, currency, category));
        }

        // Debug/testing only: fires the loan/card due-date reminder notification right
        // now, using the exact same code the real alarm uses.
        @JavascriptInterface
        public void testBillReminderNow(String name, double amount, String currency) {
            activity.runOnUiThread(() -> BillReminderReceiver.fireNotification(activity, name, amount, currency, false));
        }
    }
}
