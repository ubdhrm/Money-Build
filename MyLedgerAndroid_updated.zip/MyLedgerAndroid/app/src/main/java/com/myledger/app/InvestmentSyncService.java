package com.myledger.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Runs the app's own page in an invisible, headless WebView so the investment
 * auto-debit gets written into the ledger (localStorage) even if the user
 * never opens the app after the alarm fires. index.html already calls
 * importPendingInvestmentTransactions() unconditionally the moment it loads —
 * this service just gives it a chance to run in the background.
 */
public class InvestmentSyncService extends Service {
    private static final int NOTIF_ID = 480001;
    private static final String CHANNEL_ID = "myledger_investment_reminders";
    private WebView webView;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        InvestmentReceiver.log(this, "syncServiceStart", "");
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(new NotificationChannel(
                        CHANNEL_ID, "Investment updates", NotificationManager.IMPORTANCE_MIN));
            }
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        Notification n = b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Updating investments")
                .setPriority(Notification.PRIORITY_MIN)
                .build();
        startForeground(NOTIF_ID, n);

        try {
            webView = new WebView(getApplicationContext());
            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            webView.addJavascriptInterface(new SyncBridge(), "AndroidBridge");
            webView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    // The import call runs synchronously as the page's script
                    // executes, before onPageFinished fires — a short extra
                    // delay just gives localStorage a safety margin before we
                    // tear the WebView down.
                    new Handler(Looper.getMainLooper()).postDelayed(InvestmentSyncService.this::finish, 1500);
                }
            });
            webView.loadUrl("file:///android_asset/www/index.html");
            // Safety timeout in case onPageFinished never fires.
            new Handler(Looper.getMainLooper()).postDelayed(this::finish, 8000);
        } catch (Exception e) {
            finish();
        }
        return START_NOT_STICKY;
    }

    private void finish() {
        InvestmentReceiver.log(this, "syncServiceFinish", "");
        try { if (webView != null) { webView.destroy(); webView = null; } } catch (Exception ignored) {}
        try { stopForeground(true); } catch (Exception ignored) {}
        stopSelf();
    }

    /** Minimal bridge — only what index.html's unconditional startup import
     *  needs. Every other AndroidBridge.xxx call in index.html is guarded
     *  with a truthy check first, so omitted methods are safely skipped. */
    private class SyncBridge {
        @JavascriptInterface
        public String getPendingInvestments() { return InvestmentReceiver.getPending(InvestmentSyncService.this); }
        @JavascriptInterface
        public void clearPendingInvestments() { InvestmentReceiver.clearPending(InvestmentSyncService.this); }
    }
}
