# My Ledger — Android APK build

This repo wraps the `www/index.html` app (banks, cash, credit cards, loans,
bill reminders) in a Capacitor shell and uses GitHub Actions to build a
debug `.apk` automatically — no local Android Studio needed.

## 1. Push this to GitHub

```bash
cd my-ledger-app
git init
git add .
git commit -m "My Ledger app"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

(Or: create a new repo on github.com, then use "Upload files" in the
browser and drag in everything from this folder, keeping the folder
structure — including the hidden `.github` folder.)

## 2. Let the Action build the APK

As soon as you push to `main`, GitHub Actions runs automatically.

- Go to your repo → **Actions** tab → open the latest **"Build Android APK"** run.
- Wait for it to finish (a few minutes).
- Scroll to the bottom → under **Artifacts**, download **`my-ledger-debug-apk`**.
- Unzip it — inside is `app-debug.apk`.

If it doesn't start automatically, open the **Actions** tab → **Build
Android APK** → **Run workflow** button.

## 3. Install the APK on your phone

- Copy `app-debug.apk` to your Android phone (via USB, Drive, WhatsApp, etc.).
- Tap it to install. Android will warn about "unknown sources" the first
  time — allow it for this file. This is a debug build, not from the Play
  Store, so that warning is expected.

## What's inside the app

- **Accounts**: add Bank, Cash, Credit card, or Loan accounts, each with
  its own currency.
- **Credit cards & loans**: set what you currently owe, an optional bill/EMI
  due day (1–31), and a credit limit (for cards). The app shows how much is
  owed and when it's next due.
- **Bill reminders**: a card on the home screen lists upcoming/overdue
  bills, with a warning banner when something is due within 3 days.
  Tap **🔔 Remind me** once to allow notifications — after that, the app
  will also raise a phone notification when a bill is due soon (checked
  each time the app is opened).
- Everything else (expenses, income, transfers, savings goal, monthly
  breakdown) works as before.

All data stays on the device (browser local storage) — nothing is sent
anywhere.

## Notes

- This builds a **debug** APK, which is fine for installing on your own
  phone. If you later want to publish it on the Play Store, you'd need to
  build and sign a **release** APK/AAB instead — ask if you want that
  workflow added.
- The reminder banner always works inside the app. The phone-level push
  notification depends on Android's WebView notification support and on
  you tapping "🔔 Remind me" once to grant permission — for a fully
  reliable background push (firing even when the app isn't open), a native
  plugin (`@capacitor/local-notifications`) would need to be added later.
