My Ledger - Investment + Credit Card update

1. Investments can use either a Bank Account or Credit Card as the payment source.
2. Automatic and Manual investment modes are preserved.
3. Investment totals remain separate from Total Balance.
4. Bank-funded investments reduce the selected bank balance.
5. Credit-card-funded investments increase the selected credit-card outstanding amount.
6. Transfer mode now allows payment from a bank account to a credit card, so card bills can be paid without recording the payment as a second expense.
7. Total Balance continues to count bank accounts only.
