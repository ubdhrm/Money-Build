package com.myledger.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private WebView webView;
    private String currentTab = "home";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AlarmScheduler.ensureChannel(this);
        requestNotificationPermissionIfNeeded();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);

        webView.addJavascriptInterface(new WebAppInterface(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
            }
        }
    }

    /**
     * Back button: first press returns to the Home tab (matching what's on screen to the
     * app's actual home), a second press from Home exits the app like a normal Android app.
     */
    @Override
    public void onBackPressed() {
        if (!"home".equals(currentTab)) {
            currentTab = "home";
            if (webView != null) {
                webView.evaluateJavascript("window.__goHome && window.__goHome();", null);
            }
        } else {
            super.onBackPressed();
        }
    }

    private class WebAppInterface {

        @JavascriptInterface
        public void setTab(String tab) {
            if (tab != null) currentTab = tab;
        }

        @JavascriptInterface
        public void requestNotifPermission() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    requestNotificationPermissionIfNeeded();
                }
            });
        }

        @JavascriptInterface
        public void syncBills(String json) {
            try {
                JSONArray arr = new JSONArray(json);
                List<AlarmScheduler.BillInfo> bills = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String name = o.optString("name", null);
                    int dueDay = o.optInt("dueDay", -1);
                    if (name == null || dueDay < 1 || dueDay > 31) continue;
                    String owedText = o.optString("currency", "") + " " + o.optDouble("owed", 0);
                    bills.add(new AlarmScheduler.BillInfo(name, dueDay, owedText));
                }
                final List<AlarmScheduler.BillInfo> finalBills = bills;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        AlarmScheduler.sync(MainActivity.this, finalBills);
                    }
                });
            } catch (Exception ignored) {
                // Malformed payload from the page - ignore, next successful sync will catch up.
            }
        }
    }
}
