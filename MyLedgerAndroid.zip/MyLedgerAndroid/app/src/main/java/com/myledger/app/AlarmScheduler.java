package com.myledger.app;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

/**
 * Schedules a local (device) notification for each credit-card / EMI account that has a
 * due day set. These fire from the OS itself via AlarmManager, so they still show up even
 * if the app has been closed - unlike the web Notification API, which is not available
 * inside a plain WebView.
 */
class AlarmScheduler {

    private static final String PREFS = "ml_bill_reminders";
    private static final String KEY_NAMES = "bill_names";
    static final String CHANNEL_ID = "bill_reminders";

    static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = ctx.getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "Bill & EMI reminders", NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("Reminders for credit card bill and EMI due dates");
                nm.createNotificationChannel(channel);
            }
        }
    }

    /** Replace the full set of tracked bills with the ones currently in the app, (re)scheduling each. */
    static void sync(Context ctx, java.util.List<BillInfo> bills) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> oldNames = new HashSet<>(prefs.getStringSet(KEY_NAMES, new HashSet<String>()));
        Set<String> newNames = new HashSet<>();

        SharedPreferences.Editor editor = prefs.edit();
        for (BillInfo b : bills) {
            newNames.add(b.name);
            editor.putInt("day_" + b.name, b.dueDay);
            editor.putString("owed_" + b.name, b.owedText);
        }
        editor.putStringSet(KEY_NAMES, newNames);
        editor.apply();

        // Cancel bills that no longer exist / no longer have a due day.
        for (String name : oldNames) {
            if (!newNames.contains(name)) {
                cancel(ctx, name);
            }
        }
        // (Re)schedule current ones - cheap enough to just redo every sync.
        for (BillInfo b : bills) {
            scheduleNext(ctx, b.name, b.dueDay, b.owedText);
        }
    }

    /** Reschedule everything from persisted state - used after a device reboot and after a fired alarm. */
    static void rescheduleAll(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> names = prefs.getStringSet(KEY_NAMES, new HashSet<String>());
        for (String name : names) {
            int day = prefs.getInt("day_" + name, -1);
            String owed = prefs.getString("owed_" + name, "");
            if (day >= 1 && day <= 31) {
                scheduleNext(ctx, name, day, owed);
            }
        }
    }

    static void rescheduleOne(Context ctx, String name) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int day = prefs.getInt("day_" + name, -1);
        String owed = prefs.getString("owed_" + name, "");
        if (day >= 1 && day <= 31) {
            scheduleNext(ctx, name, day, owed);
        }
    }

    private static void scheduleNext(Context ctx, String name, int dueDay, String owedText) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 9);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        cal.set(Calendar.DAY_OF_MONTH, Math.min(dueDay, maxDay));
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(Calendar.MONTH, 1);
            maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
            cal.set(Calendar.DAY_OF_MONTH, Math.min(dueDay, maxDay));
        }

        Intent intent = new Intent(ctx, BillReminderReceiver.class);
        intent.putExtra("name", name);
        intent.putExtra("owedText", owedText);
        PendingIntent pi = PendingIntent.getBroadcast(
                ctx, name.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            }
        } catch (SecurityException ignored) {
            // Some OEMs restrict alarms; nothing more we can do here.
        }
    }

    private static void cancel(Context ctx, String name) {
        Intent intent = new Intent(ctx, BillReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                ctx, name.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pi);

        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().remove("day_" + name).remove("owed_" + name).apply();
    }

    static class BillInfo {
        final String name;
        final int dueDay;
        final String owedText;
        BillInfo(String name, int dueDay, String owedText) {
            this.name = name;
            this.dueDay = dueDay;
            this.owedText = owedText;
        }
    }
}
