package com.myledger.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Transparent popup shown directly over the home screen when a widget is tapped.
 * It loads the same index.html (same localStorage as the main app) in "popup mode",
 * so only the quick-add dialog is visible and the full app never opens.
 */
public class QuickAddActivity extends Activity {

    private WebView webView;
    private String quick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        quick = getIntent() != null ? getIntent().getStringExtra("quick_entry") : null;

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("if(window.__checkQuick){window.__checkQuick();}", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(QuickAddActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.confirm())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(QuickAddActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });
        webView.addJavascriptInterface(new PopupBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/www/index.html?popup=1");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String q = intent != null ? intent.getStringExtra("quick_entry") : null;
        if (q != null) {
            quick = q;
            if (webView != null) webView.reload();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Leaving the popup (home button / recents) just dismisses it.
        if (isFinishing()) return;
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    /** Minimal bridge: only what the popup needs; everything else is a harmless no-op
     *  so the popup never touches alarms, pending investments or notifications. */
    private class PopupBridge {
        @JavascriptInterface public String consumeQuick() { String q = quick; quick = null; return q == null ? "" : q; }
        @JavascriptInterface public void closePopup() { runOnUiThread(QuickAddActivity.this::finish); }
        @JavascriptInterface public void setCurrentTab(String tab) { }
        @JavascriptInterface public void setDetailOpen(boolean open) { }
        @JavascriptInterface public void requestBillNotifications() { }
        @JavascriptInterface public void scheduleBillReminder(String n, double a, String c, int d) { }
        @JavascriptInterface public void cancelBillReminder(String n) { }
        @JavascriptInterface public void scheduleInvestment(String id, String name, double amount, String account, String currency, String frequency, String startDate, String category, String time) { }
        @JavascriptInterface public void cancelInvestment(String id) { }
        @JavascriptInterface public int getAppVersionCode() { return 0; }
        @JavascriptInterface public void openUrl(String url) { }
        @JavascriptInterface public String getPendingInvestments() { return "[]"; }
        @JavascriptInterface public void clearPendingInvestments() { }
        @JavascriptInterface public String getInvestmentDebugLog() { return ""; }
        @JavascriptInterface public void notifyPendingInvestment(String name, double amount, String currency) { }
        @JavascriptInterface public void testInvestmentNow(String id, String name, double amount, String account, String currency, String category) { }
        @JavascriptInterface public void testBillReminderNow(String name, double amount, String currency) { }
        @JavascriptInterface public void exportPdf(String jobName) { }
        @JavascriptInterface public void updateWidget(String json) { SummaryWidget.store(getApplicationContext(), json); }
    }
}
