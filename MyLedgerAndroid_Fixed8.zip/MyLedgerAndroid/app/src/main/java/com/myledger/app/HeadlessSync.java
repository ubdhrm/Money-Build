package com.myledger.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.List;

/**
 * Loads the app's own page in an invisible WebView so index.html's startup
 * import writes pending auto-investments into the ledger (localStorage) even
 * when the app UI is not open. MAIN THREAD ONLY.
 *
 * Several alarms can fire at the same minute (two plans at 09:00). Instead of
 * creating competing WebViews, a call that arrives while one is running marks
 * a re-run: the page is loaded once more after the current cycle, so a plan
 * queued mid-cycle is never missed. Every caller's callback runs after the
 * final cycle.
 */
final class HeadlessSync {
    private static final long PAGE_SETTLE_MS = 1500;
    private static final long TIMEOUT_MS = 7000;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final List<Runnable> WAITERS = new ArrayList<>();
    private static WebView webView;
    private static int generation;
    private static boolean rerun;

    private HeadlessSync() {}

    static void run(Context context, Runnable onDone) {
        WAITERS.add(onDone);
        if (webView != null) { rerun = true; return; }
        start(context.getApplicationContext());
    }

    private static void start(final Context app) {
        final int gen = ++generation;
        WebView wv = null;
        try {
            wv = new WebView(app);
            WebSettings s = wv.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            wv.addJavascriptInterface(new Bridge(app), "AndroidBridge");
            wv.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    MAIN.postDelayed(() -> finish(app, gen), PAGE_SETTLE_MS);
                }
            });
            webView = wv;
            wv.loadUrl("file:///android_asset/www/index.html");
            MAIN.postDelayed(() -> finish(app, gen), TIMEOUT_MS);
        } catch (Exception e) {
            InvestmentReceiver.log(app, "headlessSyncError", e.getClass().getSimpleName() + ": " + e.getMessage());
            try { if (wv != null) wv.destroy(); } catch (Exception ignored) {}
            webView = null;
            rerun = false;
            flush();
        }
    }

    private static void finish(Context app, int gen) {
        if (gen != generation || webView == null) return; // stale timer
        try { webView.destroy(); } catch (Exception ignored) {}
        webView = null;
        if (rerun) { rerun = false; start(app); return; }
        flush();
    }

    private static void flush() {
        List<Runnable> copy = new ArrayList<>(WAITERS);
        WAITERS.clear();
        for (Runnable r : copy) {
            try { r.run(); } catch (Exception ignored) {}
        }
    }

    /** Only what index.html's unconditional startup import needs; every other
     *  AndroidBridge.xxx call in index.html is guarded by a truthy check. */
    private static final class Bridge {
        private final Context app;
        Bridge(Context app) { this.app = app; }
        @JavascriptInterface public String getPendingInvestments() { return InvestmentReceiver.getPending(app); }
        @JavascriptInterface public void clearPendingInvestments() { InvestmentReceiver.clearPending(app); }
        @JavascriptInterface public void updateWidget(String json) { SummaryWidget.store(app, json); }
    }
}
