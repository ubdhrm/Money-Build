package com.myledger.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Iterator;

public class MainActivity extends Activity {

    private static final int NOTIFICATION_PERMISSION_REQUEST = 1001;
    static final String CHANNEL_ID = "myledger_bill_reminders";
    private static final String PREFS = "myledger_reminders";
    private static final String REMINDERS_JSON = "reminders";
    private WebView webView;
    private String currentTab = "transactions";
    private boolean detailOpen = false;
    static volatile String PENDING_QUICK = null;
    /** The live activity, if the app process currently has one. Lets a due
     *  auto-investment be imported by the live page instead of a competing
     *  headless WebView (see InvestmentReceiver.handleDue). */
    static volatile MainActivity CURRENT = null;

    /** Runs the page's refresh (reload ledger from storage, import pending
     *  investments, re-render) and then calls after. Main thread only. */
    void syncNow(final Runnable after) {
        if (webView == null) { after.run(); return; }
        webView.evaluateJavascript(
                "if(window.myLedgerRefresh){window.myLedgerRefresh();}",
                value -> after.run());
    }

    @Override
    protected void onDestroy() {
        if (CURRENT == this) CURRENT = null;
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-arm on every resume too, not just onCreate — covers the case where
        // the app was only backgrounded (no onCreate) but an OEM battery manager
        // cleared the alarm while it sat in the background.
        InvestmentReceiver.rescheduleAll(this);
        // The WebView/JS keeps running while the app is only backgrounded (not
        // killed), so index.html's one-time startup import never re-fires on
        // its own. Re-run it here so anything that posted while the app was in
        // the background (or just sitting on the home screen) shows up as soon
        // as the user comes back in, instead of only after a full relaunch.
        if (webView != null) {
            webView.evaluateJavascript("if(window.myLedgerRefresh){window.myLedgerRefresh();} if(window.__checkQuick){window.__checkQuick();}", null);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CURRENT = this;

        createNotificationChannel();
        createInvestmentNotificationChannel();

        // Safety net: re-arm any investment auto-debit alarms every time the app is
        // opened. Some OEMs (Xiaomi/Vivo/Oppo/Realme battery managers, or a user
        // swiping the app away from recents) silently cancel pending AlarmManager
        // alarms without a reboot, which otherwise means BOOT_COMPLETED never gets
        // a chance to restore them. This makes the schedule self-healing.
        InvestmentReceiver.rescheduleAll(this);
        requestIgnoreBatteryOptimizationsOnce();
        requestExactAlarmPermissionOnce();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);

        PENDING_QUICK = getIntent() != null ? getIntent().getStringExtra("quick_entry") : null;
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("if(window.__checkQuick){window.__checkQuick();}", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.confirm())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .setCancelable(true)
                        .show();
                return true;
            }
        });
        webView.addJavascriptInterface(new LedgerBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String q = intent != null ? intent.getStringExtra("quick_entry") : null;
        if (q != null) {
            PENDING_QUICK = q;
            if (webView != null) {
                webView.evaluateJavascript("if(window.__checkQuick){window.__checkQuick();}", null);
            }
        }
    }

    @Override
    public void onBackPressed() {
        // If the Add Expense/Income screen is open, back just closes it and
        // returns to the app's home instead of exiting the app.
        if (webView != null) {
            webView.evaluateJavascript(
                    "(function(){var r=0;['addSheet','qaModal'].forEach(function(id){var o=document.getElementById(id);if(o){o.remove();r=1;}});return r;})()",
                    value -> { if (!"1".equals(value)) handleBack(); });
        } else {
            handleBack();
        }
    }

    private void handleBack() {
        if (detailOpen) {
            detailOpen = false;
            if (webView != null) {
                webView.evaluateJavascript("if(window.__closeDetailModal){window.__closeDetailModal();}", null);
            }
            return;
        }
        if (!"transactions".equals(currentTab)) {
            currentTab = "transactions";
            if (webView != null) {
                webView.evaluateJavascript("if(window.__switchToHome){window.__switchToHome();}", null);
            }
            return;
        }
        super.onBackPressed();
    }

    public void setCurrentTab(String tab) {
        if (tab != null && !tab.isEmpty()) currentTab = tab;
    }

    public void setDetailOpen(boolean open) {
        detailOpen = open;
    }

    public void requestBillNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    public void scheduleBillReminder(String name, double amount, String currency, int dueDay) {
        if (name == null || name.trim().isEmpty() || dueDay < 1 || dueDay > 31) return;
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(REMINDERS_JSON, "[]"));
            JSONArray out = new JSONArray();
            boolean replaced = false;

            for (int i = 0; i < old.length(); i++) {
                JSONObject item = old.optJSONObject(i);
                if (item == null) continue;
                if (name.equals(item.optString("name"))) {
                    JSONObject replacement = new JSONObject();
                    replacement.put("name", name);
                    replacement.put("amount", amount);
                    replacement.put("currency", currency == null ? "" : currency);
                    replacement.put("dueDay", dueDay);
                    out.put(replacement);
                    replaced = true;
                } else {
                    out.put(item);
                }
            }
            if (!replaced) {
                JSONObject item = new JSONObject();
                item.put("name", name);
                item.put("amount", amount);
                item.put("currency", currency == null ? "" : currency);
                item.put("dueDay", dueDay);
                out.put(item);
            }
            sp.edit().putString(REMINDERS_JSON, out.toString()).apply();
            BillReminderReceiver.schedule(this, name, amount, currency, dueDay);
        } catch (Exception ignored) {
        }
    }

    public void cancelBillReminder(String name) {
        if (name == null || name.isEmpty()) return;
        BillReminderReceiver.cancel(this, name);
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(REMINDERS_JSON, "[]"));
            JSONArray out = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject item = old.optJSONObject(i);
                if (item != null && !name.equals(item.optString("name"))) out.put(item);
            }
            sp.edit().putString(REMINDERS_JSON, out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public void rescheduleSavedReminders() {
        try {
            JSONArray items = new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(REMINDERS_JSON, "[]"));
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                BillReminderReceiver.schedule(
                        this,
                        item.optString("name"),
                        item.optDouble("amount", 0),
                        item.optString("currency"),
                        item.optInt("dueDay", 0)
                );
            }
        } catch (Exception ignored) {
        }
    }

    public int getAppVersionCode() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionCode;
        } catch (Exception e) {
            return -1;
        }
    }

    public void openUrl(String url) {
        if (url == null || url.trim().isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) {
        }
    }

    /** Hands the current WebView page to Android's built-in print framework, where
     *  "Save as PDF" is one of the destinations — no bundled PDF library needed.
     *  The JS side prepares a print-only summary (hidden the rest of the app via
     *  @media print) before calling this, so only that summary ends up on paper. */
    public void exportPdf(String jobName) {
        if (webView == null) return;
        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        if (printManager == null) return;
        String name = (jobName == null || jobName.trim().isEmpty()) ? "MyLedger Summary" : jobName.trim();
        try {
            PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(name);
            printManager.print(name, adapter, new PrintAttributes.Builder().build());
        } catch (Exception ignored) {
        }
    }

    /** Battery optimization is the other big reason auto-debit alarms silently
     *  stop firing: if the OS is allowed to Doze/kill this app aggressively,
     *  the "next" alarm re-armed inside InvestmentReceiver.onReceive may never
     *  get the chance to run. Ask the user once to exempt the app; if they
     *  decline, we don't nag again (the onResume safety net above still helps). */
    private void requestIgnoreBatteryOptimizationsOnce() {
        if (Build.VERSION.SDK_INT < 23) return;
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (sp.getBoolean("askedBatteryOptimization", false)) return;
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent intent = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        } catch (Exception ignored) {
        }
        sp.edit().putBoolean("askedBatteryOptimization", true).apply();
    }

    /** On Android 12+, exact alarms need this separate "Alarms & reminders"
     *  special access — canScheduleExactAlarms() stays false without it, and
     *  the scheduler silently falls back to the less reliable inexact alarm. */
    private void requestExactAlarmPermissionOnce() {
        if (Build.VERSION.SDK_INT < 31) return;
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (sp.getBoolean("askedExactAlarm", false)) return;
        try {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                Intent intent = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        } catch (Exception ignored) {
        }
        sp.edit().putBoolean("askedExactAlarm", true).apply();
    }

    private void createInvestmentNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("myledger_investment_reminders", "Investment updates", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Automatic investment transaction updates");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Bill & EMI reminders",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Credit card and EMI due-date reminders");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    public static class LedgerBridge {
        @JavascriptInterface
        public String consumeQuick() {
            String q = MainActivity.PENDING_QUICK;
            MainActivity.PENDING_QUICK = null;
            return q == null ? "" : q;
        }

        private final MainActivity activity;
        LedgerBridge(MainActivity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public void setCurrentTab(String tab) {
            activity.setCurrentTab(tab);
        }

        @JavascriptInterface
        public void setDetailOpen(boolean open) {
            activity.runOnUiThread(() -> activity.setDetailOpen(open));
        }

        @JavascriptInterface
        public void requestBillNotifications() {
            activity.runOnUiThread(activity::requestBillNotifications);
        }

        @JavascriptInterface
        public void scheduleBillReminder(String name, double amount, String currency, int dueDay) {
            activity.runOnUiThread(() -> activity.scheduleBillReminder(name, amount, currency, dueDay));
        }

        @JavascriptInterface
        public void cancelBillReminder(String name) {
            activity.runOnUiThread(() -> activity.cancelBillReminder(name));
        }

        @JavascriptInterface
        public void scheduleInvestment(String id, String name, double amount, String account, String currency, String frequency, String startDate, String category, String time) {
            activity.runOnUiThread(() -> InvestmentReceiver.schedule(activity, id, name, amount, account, currency, frequency, startDate, category, time));
        }

        @JavascriptInterface
        public void cancelInvestment(String id) {
            activity.runOnUiThread(() -> InvestmentReceiver.cancel(activity, id));
        }

        @JavascriptInterface
        public int getAppVersionCode() { return activity.getAppVersionCode(); }

        @JavascriptInterface
        public void openUrl(String url) {
            activity.runOnUiThread(() -> activity.openUrl(url));
        }

        @JavascriptInterface
        public String getPendingInvestments() { return InvestmentReceiver.getPending(activity); }

        @JavascriptInterface
        public void clearPendingInvestments() { activity.runOnUiThread(() -> InvestmentReceiver.clearPending(activity)); }

        @JavascriptInterface
        public String getInvestmentDebugLog() { return InvestmentReceiver.getDebugLog(activity); }

        // Called from the home-screen "Today's investment" popup (the fallback shown
        // when a due auto-investment hasn't been posted yet) so the user also gets a
        // system notification, not just the in-app popup. Does not write anything to
        // the ledger by itself.
        @JavascriptInterface
        public void notifyPendingInvestment(String name, double amount, String currency) {
            activity.runOnUiThread(() -> InvestmentReceiver.notifyPending(activity, name, amount, currency));
        }

        // Debug/testing only: posts one investment cycle right now, using the exact
        // same pending-write + notification code the real 9am alarm uses — so you can
        // verify the whole auto-debit pipeline works without waiting for the clock.
        @JavascriptInterface
        public void testInvestmentNow(String id, String name, double amount, String account, String currency, String category) {
            activity.runOnUiThread(() -> InvestmentReceiver.handleDue(activity, id, name, amount, account, currency, category, null));
        }

        // Debug/testing only: fires the loan/card due-date reminder notification right
        // now, using the exact same code the real alarm uses.
        @JavascriptInterface
        public void testBillReminderNow(String name, double amount, String currency) {
            activity.runOnUiThread(() -> BillReminderReceiver.fireNotification(activity, name, amount, currency, false));
        }

        @JavascriptInterface
        public void updateWidget(String json) {
            SummaryWidget.store(activity.getApplicationContext(), json);
        }

        @JavascriptInterface
        public void exportPdf(String jobName) {
            activity.runOnUiThread(() -> activity.exportPdf(jobName));
        }
    }
}
