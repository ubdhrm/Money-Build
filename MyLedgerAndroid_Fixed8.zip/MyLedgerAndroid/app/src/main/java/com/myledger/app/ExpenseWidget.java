package com.myledger.app;

public class ExpenseWidget extends QuickAddWidget {
    @Override protected String type() { return "expense"; }
    @Override protected int layoutId() { return R.layout.widget_expense; }
    @Override protected int requestCode() { return 7101; }
}
