package com.myledger.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/**
 * Keeps the process alive while HeadlessSync writes the due auto-investment into
 * the ledger. When that finishes it posts the real outcome notification:
 * "Investment posted" only if the entry is really in the ledger, otherwise
 * "Investment due - open app" (the entry stays safely in the pending queue and is
 * imported the next time the app opens).
 */
public class InvestmentSyncService extends Service {
    private static final int NOTIF_ID = 480001;
    // Separate silent channel for the progress notification, so it can never
    // downgrade the channel used for the "Investment posted" notification.
    private static final String CHANNEL_ID = "myledger_sync_progress";

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        InvestmentReceiver.log(this, "syncServiceStart", "");
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationManager nm = getSystemService(NotificationManager.class);
                if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                    nm.createNotificationChannel(new NotificationChannel(
                            CHANNEL_ID, "Background sync", NotificationManager.IMPORTANCE_MIN));
                }
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
            Notification n = b.setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("Updating investments")
                    .setPriority(Notification.PRIORITY_MIN)
                    .build();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            InvestmentReceiver.log(this, "startForegroundError", e.getClass().getSimpleName() + ": " + e.getMessage());
        }

        final Context app = getApplicationContext();
        final String id = intent == null ? null : intent.getStringExtra("id");
        final String name = intent == null ? null : intent.getStringExtra("name");
        final double amount = intent == null ? 0 : intent.getDoubleExtra("amount", 0);
        final String currency = intent == null ? null : intent.getStringExtra("currency");

        HeadlessSync.run(this, () -> {
            if (id != null) InvestmentReceiver.notifyOutcome(app, id, name, amount, currency);
            InvestmentReceiver.log(app, "syncServiceFinish", "");
            try { stopForeground(true); } catch (Exception ignored) {}
            stopSelf();
        });
        return START_NOT_STICKY;
    }
}
