package com.myledger.app;

public class IncomeWidget extends QuickAddWidget {
    @Override protected String type() { return "income"; }
    @Override protected int layoutId() { return R.layout.widget_income; }
    @Override protected int requestCode() { return 7102; }
}
