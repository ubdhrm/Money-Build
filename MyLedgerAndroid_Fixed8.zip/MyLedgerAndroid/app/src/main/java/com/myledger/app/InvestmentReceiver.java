package com.myledger.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class InvestmentReceiver extends BroadcastReceiver {
    private static final String ACTION = "com.myledger.app.INVESTMENT_DUE";
    private static final String PREFS = "myledger_investments_native";
    private static final String PLANS = "plans";
    private static final String PENDING = "pending";
    private static final String CHANNEL_ID = "myledger_investment_reminders";
    private static final String DEBUG_LOG = "debugLog";
    private static final long RECEIVER_GUARD_MS = 8500; // broadcasts must finish well inside ~10s
    /** Guards read-modify-write of the pending queue (receiver, service and WebView bridge threads). */
    private static final Object LOCK = new Object();

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        log(context, "onReceive", "action=" + action);
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            // Reboot and app update both wipe every alarm: re-arm unconditionally.
            rescheduleAll(context, true);
            return;
        }
        if (!ACTION.equals(action)) return;

        String id = intent.getStringExtra("id"), name = intent.getStringExtra("name"), account = intent.getStringExtra("account");
        double amount = intent.getDoubleExtra("amount", 0);
        String currency = intent.getStringExtra("currency"), frequency = intent.getStringExtra("frequency");
        String category = intent.getStringExtra("category"), time = intent.getStringExtra("time");

        // Re-arm the NEXT occurrence first, so the schedule survives even if
        // anything below fails.
        try { schedule(context, id, name, amount, account, currency, frequency, intent.getStringExtra("startDate"), category, time); } catch (Exception ignored) {}

        PendingResult pr = null;
        try { pr = goAsync(); } catch (Exception ignored) {}
        handleDue(context, id, name, amount, account, currency, category, pr);
    }

    /** One due auto-investment: queue it, get it into the ledger by the most
     *  reliable route available, then tell the user what REALLY happened.
     *  Used by the real alarm and by the in-app "Test debit now" button.
     *  Main thread only. */
    static void handleDue(Context ctx, final String id, final String name, final double amount, String account,
                          final String currency, String category, final BroadcastReceiver.PendingResult pr) {
        final Context app = ctx.getApplicationContext();
        postPending(app, id, name, amount, account, currency, category);

        final AtomicBoolean receiverDone = new AtomicBoolean(false);
        final Runnable finishReceiver = () -> {
            if (receiverDone.compareAndSet(false, true) && pr != null) {
                try { pr.finish(); } catch (Exception ignored) {}
            }
        };
        final AtomicBoolean notified = new AtomicBoolean(false);
        final Runnable outcome = () -> {
            if (notified.compareAndSet(false, true)) notifyOutcome(app, id, name, amount, currency);
            finishReceiver.run();
        };

        // 1) App process is alive: let the live page import it. Writing from a
        //    second headless WebView would be overwritten by the live page's
        //    stale in-memory list on its next save.
        MainActivity live = MainActivity.CURRENT;
        if (live != null) {
            log(app, "dueViaLivePage", "id=" + id);
            new Handler(Looper.getMainLooper()).postDelayed(outcome, RECEIVER_GUARD_MS);
            live.syncNow(outcome);
            return;
        }

        // 2) App not running: foreground service + headless page.
        boolean started = false;
        try {
            Intent sync = new Intent(app, InvestmentSyncService.class);
            sync.putExtra("id", id);
            sync.putExtra("name", name);
            sync.putExtra("amount", amount);
            sync.putExtra("currency", currency == null ? "" : currency);
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(sync);
            else app.startService(sync);
            started = true;
            log(app, "dueViaService", "id=" + id);
        } catch (Exception e) {
            // Android 12+ blocks starting a foreground service from the background
            // unless the exact-alarm permission is granted. This used to be swallowed
            // silently while the notification still claimed "posted".
            log(app, "serviceStartFailed", e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        if (started) { finishReceiver.run(); return; }

        // 3) Service not allowed: run the headless page right here, inside the
        //    receiver's goAsync() window.
        log(app, "dueViaReceiverFallback", "id=" + id);
        new Handler(Looper.getMainLooper()).postDelayed(outcome, RECEIVER_GUARD_MS);
        HeadlessSync.run(app, outcome);
    }

    /** Queues one pending entry. Idempotent per plan per day, so a repeated alarm,
     *  test tap or retry can't queue the same debit twice. Does NOT notify. */
    public static void postPending(Context context, String id, String name, double amount, String account, String currency, String category) {
        String date = today();
        synchronized (LOCK) {
            try {
                SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                JSONArray pending = new JSONArray(sp.getString(PENDING, "[]"));
                for (int n = 0; n < pending.length(); n++) {
                    JSONObject o = pending.optJSONObject(n);
                    if (o != null && id != null && id.equals(o.optString("investmentId")) && date.equals(o.optString("date"))) return;
                }
                JSONObject item = new JSONObject();
                item.put("investmentId", id); item.put("name", name); item.put("account", account);
                item.put("amount", amount); item.put("currency", currency == null ? "" : currency);
                item.put("category", category == null ? "Investment" : category); item.put("date", date);
                pending.put(item);
                sp.edit().putString(PENDING, pending.toString()).commit(); // commit: must survive the process dying right after
            } catch (Exception e) {
                log(context, "postPendingError", e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }
    }

    /** Tells the truth: "posted" only if the entry has left the pending queue
     *  (i.e. the page imported it into the ledger). */
    static void notifyOutcome(Context c, String id, String name, double amount, String currency) {
        if (isPending(c, id, today())) {
            showNotification(c, name, amount, currency, "Investment due \u2013 open app to add it");
        } else {
            showNotification(c, name, amount, currency, "Investment posted");
        }
    }

    private static boolean isPending(Context c, String id, String date) {
        if (id == null) return false;
        synchronized (LOCK) {
            try {
                JSONArray a = new JSONArray(getPending(c));
                for (int n = 0; n < a.length(); n++) {
                    JSONObject o = a.optJSONObject(n);
                    if (o != null && id.equals(o.optString("investmentId")) && date.equals(o.optString("date"))) return true;
                }
            } catch (Exception ignored) {}
        }
        return false;
    }

    /** Fires a "Pending debit" notification for an auto-investment that's due today
     *  but hasn't been posted yet (the in-app home-screen popup asking the user to
     *  confirm it). Unlike postPending, this does NOT write anything to the ledger. */
    public static void notifyPending(Context context, String name, double amount, String currency) {
        showNotification(context, name, amount, currency, "Pending debit");
    }

    public static void schedule(Context context, String id, String name, double amount, String account, String currency, String frequency, String startDate, String category, String time) {
        if (id == null || id.isEmpty() || amount <= 0 || frequency == null) return;
        try {
            int hour = 9, minute = 0;
            if (time != null && time.matches("^\\d{1,2}:\\d{2}$")) {
                String[] parts = time.split(":");
                int h = Integer.parseInt(parts[0]), m = Integer.parseInt(parts[1]);
                if (h >= 0 && h < 24 && m >= 0 && m < 60) { hour = h; minute = m; }
            }
            Calendar now = Calendar.getInstance();
            Calendar start = Calendar.getInstance();
            if (startDate != null && !startDate.isEmpty()) {
                Date parsed = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(startDate);
                if (parsed != null) start.setTime(parsed);
            }
            start.set(Calendar.HOUR_OF_DAY, hour); start.set(Calendar.MINUTE, minute);
            start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0);

            // Each occurrence is computed from the ORIGINAL start date. Stepping
            // "+1 month" repeatedly drifts a 31st-of-month plan to the 28th forever
            // after passing through February.
            Calendar when = (Calendar) start.clone();
            int n = 0;
            while (!when.after(now) && n < 50000) { n++; when = occurrence(start, frequency, n); }

            Intent i = new Intent(context, InvestmentReceiver.class); i.setAction(ACTION);
            i.putExtra("id", id); i.putExtra("name", name); i.putExtra("amount", amount); i.putExtra("account", account);
            i.putExtra("currency", currency == null ? "" : currency); i.putExtra("frequency", frequency);
            i.putExtra("startDate", startDate == null ? "" : startDate); i.putExtra("category", category == null ? "Investment" : category);
            i.putExtra("time", time == null ? "09:00" : time);
            PendingIntent pi = PendingIntent.getBroadcast(context, requestCode(id), i, flags());
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            boolean canExact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            if (Build.VERSION.SDK_INT >= 23 && canExact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            else if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            else am.set(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi);
            savePlan(context, id, name, amount, account, currency, frequency, startDate, category, time);
            log(context, "scheduled", "id=" + id + " for=" + new SimpleDateFormat("dd MMM HH:mm:ss", Locale.US).format(when.getTime()) + " exact=" + canExact + " sdk=" + Build.VERSION.SDK_INT);
        } catch (Exception e) {
            log(context, "scheduleError", "id=" + id + " err=" + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    private static Calendar occurrence(Calendar start, String f, int n) {
        Calendar c = (Calendar) start.clone();
        if ("daily".equals(f)) c.add(Calendar.DAY_OF_YEAR, n);
        else if ("weekly".equals(f)) c.add(Calendar.DAY_OF_YEAR, 7 * n);
        else c.add(Calendar.MONTH, n);
        return c;
    }

    private static void savePlan(Context c, String id, String name, double amount, String account, String currency, String frequency, String startDate, String category, String time) throws Exception {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray old = new JSONArray(sp.getString(PLANS, "[]")), out = new JSONArray();
        boolean found = false;
        for (int n = 0; n < old.length(); n++) {
            JSONObject o = old.optJSONObject(n);
            if (o == null) continue;
            if (id.equals(o.optString("id"))) { found = true; o = planJson(id, name, amount, account, currency, frequency, startDate, category, time); }
            out.put(o);
        }
        if (!found) out.put(planJson(id, name, amount, account, currency, frequency, startDate, category, time));
        sp.edit().putString(PLANS, out.toString()).apply();
    }

    private static JSONObject planJson(String id, String name, double amount, String account, String currency, String frequency, String startDate, String category, String time) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("name", name); o.put("amount", amount); o.put("account", account);
        o.put("currency", currency == null ? "" : currency); o.put("frequency", frequency);
        o.put("startDate", startDate == null ? "" : startDate); o.put("category", category == null ? "Investment" : category);
        o.put("time", time == null ? "09:00" : time);
        return o;
    }

    public static void cancel(Context c, String id) {
        if (id == null) return;
        Intent i = new Intent(c, InvestmentReceiver.class); i.setAction(ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(c, requestCode(id), i, flags());
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pi);
        pi.cancel();
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(PLANS, "[]")), out = new JSONArray();
            for (int n = 0; n < old.length(); n++) {
                JSONObject o = old.optJSONObject(n);
                if (o != null && !id.equals(o.optString("id"))) out.put(o);
            }
            sp.edit().putString(PLANS, out.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static void rescheduleAll(Context c) { rescheduleAll(c, false); }

    /** force=false: only re-arm alarms that are truly missing (safe to call on every app open).
     *  force=true: re-arm everything (after reboot / app update, when all alarms are gone). */
    public static void rescheduleAll(Context c, boolean force) {
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PLANS, "[]"));
            for (int n = 0; n < a.length(); n++) {
                JSONObject o = a.optJSONObject(n);
                if (o == null) continue;
                String id = o.optString("id");
                if (force || !isScheduled(c, id)) {
                    schedule(c, id, o.optString("name"), o.optDouble("amount"), o.optString("account"), o.optString("currency"), o.optString("frequency"), o.optString("startDate"), o.optString("category"), o.optString("time", "09:00"));
                }
            }
        } catch (Exception ignored) {}
    }

    /** True if an alarm is already armed for this plan. The non-forced safety net
     *  must never recompute one that's already correctly pending, or a reopen right
     *  around the due time could push today's occurrence to tomorrow. */
    private static boolean isScheduled(Context c, String id) {
        Intent i = new Intent(c, InvestmentReceiver.class); i.setAction(ACTION);
        int f = PendingIntent.FLAG_NO_CREATE | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, requestCode(id), i, f) != null;
    }

    public static String getPending(Context c) {
        synchronized (LOCK) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PENDING, "[]"); }
    }

    public static void clearPending(Context c) {
        synchronized (LOCK) { c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(PENDING, "[]").commit(); }
    }

    /** Small rolling diagnostics log (last 30 events). */
    static void log(Context c, String event, String detail) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray log = new JSONArray(sp.getString(DEBUG_LOG, "[]"));
            JSONObject e = new JSONObject(); e.put("t", new SimpleDateFormat("dd MMM HH:mm:ss", Locale.US).format(new Date())); e.put("event", event); e.put("detail", detail == null ? "" : detail);
            log.put(e);
            while (log.length() > 30) log.remove(0);
            sp.edit().putString(DEBUG_LOG, log.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static String getDebugLog(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(DEBUG_LOG, "[]"); }

    private static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    private static int requestCode(String s) { return 500000 + Math.abs((s == null ? "" : s).hashCode() % 100000); }
    private static int flags() { return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0); }

    private static void showNotification(Context c, String name, double amount, String currency, String title) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL_ID) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Investment updates", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Automatic investment transaction updates");
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, requestCode(name) + 200000, open, flags());
        String money = (currency == null ? "" : currency) + " " + String.format(Locale.US, "%.2f", amount);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL_ID) : new Notification.Builder(c);
        Notification n = b.setSmallIcon(com.myledger.app.R.mipmap.ic_launcher).setContentTitle(title)
                .setContentText(name + " \u2022 " + money).setAutoCancel(true).setContentIntent(pi)
                .setPriority(Notification.PRIORITY_DEFAULT).build();
        if (Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED)
            nm.notify(requestCode(name) + 300000, n);
    }
}
