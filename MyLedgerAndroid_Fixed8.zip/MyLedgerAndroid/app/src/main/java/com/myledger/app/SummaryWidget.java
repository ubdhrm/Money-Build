package com.myledger.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Home-screen widget: today's spending and income per currency.
 *
 * The ledger lives in the WebView's localStorage, which native code can't read.
 * So index.html pushes a small pre-formatted summary through
 * AndroidBridge.updateWidget() after every render, and this class just stores
 * it and paints it. Because the numbers are pushed (not computed here), the
 * widget always matches exactly what the app shows.
 */
public class SummaryWidget extends AppWidgetProvider {
    private static final String PREFS = "myledger_widget";
    private static final String KEY = "summary";
    private static final int MAX_ROWS = 3;
    private static final int[] ROW = {R.id.sum_row1, R.id.sum_row2, R.id.sum_row3};
    private static final int[] CUR = {R.id.sum_cur1, R.id.sum_cur2, R.id.sum_cur3};
    private static final int[] SPENT = {R.id.sum_spent1, R.id.sum_spent2, R.id.sum_spent3};
    private static final int[] E_ROW = {R.id.ent_row1, R.id.ent_row2, R.id.ent_row3, R.id.ent_row4, R.id.ent_row5};
    private static final int[] E_NAME = {R.id.ent_name1, R.id.ent_name2, R.id.ent_name3, R.id.ent_name4, R.id.ent_name5};
    private static final int[] E_AMT = {R.id.ent_amt1, R.id.ent_amt2, R.id.ent_amt3, R.id.ent_amt4, R.id.ent_amt5};
    private static final int[] BAL = {R.id.sum_bal1, R.id.sum_bal2, R.id.sum_bal3};

    /** Called by every bridge (main app, quick-add popup, headless sync). */
    static void store(Context ctx, String json) {
        if (json == null || json.isEmpty()) return;
        try {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply();
            refreshAll(ctx);
        } catch (Exception ignored) {}
    }

    static void refreshAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, SummaryWidget.class));
        if (ids == null || ids.length == 0) return;
        RemoteViews rv = build(ctx);
        for (int id : ids) mgr.updateAppWidget(id, rv);
    }

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        // Also runs every ~30 min and after reboot, which is what rolls
        // "spent today" over at midnight (see build()).
        RemoteViews rv = build(ctx);
        for (int id : ids) mgr.updateAppWidget(id, rv);
    }

    private static RemoteViews build(Context ctx) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_summary);

        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        rv.setOnClickPendingIntent(R.id.widget_root,
                PendingIntent.getActivity(ctx, 7201, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        Intent add = new Intent(ctx, QuickAddActivity.class);
        add.setAction("com.myledger.app.QUICK_EXPENSE");
        add.putExtra("quick_entry", "expense");
        add.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        rv.setOnClickPendingIntent(R.id.sum_add,
                PendingIntent.getActivity(ctx, 7202, add, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        Date now = new Date();
        rv.setTextViewText(R.id.sum_title, "Today \u00B7 " + new SimpleDateFormat("d MMM", Locale.getDefault()).format(now));

        int shown = 0;
        int listed = 0;
        int more = 0;
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String raw = sp.getString(KEY, "");
            if (!raw.isEmpty()) {
                JSONObject o = new JSONObject(raw);
                // The snapshot was taken on o.date. If that's not today, nothing has
                // been spent today yet (any new entry would have pushed a fresh
                // snapshot), so show the pre-formatted zero instead of yesterday's total.
                boolean sameDay = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now).equals(o.optString("date"));
                JSONArray list = o.optJSONArray("list");
                if (sameDay && list != null) {
                    for (int i = 0; i < list.length() && listed < E_ROW.length; i++) {
                        JSONObject r = list.optJSONObject(i);
                        if (r == null) continue;
                        rv.setViewVisibility(E_ROW[listed], View.VISIBLE);
                        rv.setTextViewText(E_NAME[listed], r.optString("n"));
                        rv.setTextViewText(E_AMT[listed], r.optString("a"));
                        rv.setTextColor(E_AMT[listed], "i".equals(r.optString("t")) ? 0xFF8CE0A8 : 0xFFFF9B9B);
                        listed++;
                    }
                    more = o.optInt("more", 0);
                }
                JSONArray rows = o.optJSONArray("rows");
                if (rows != null) {
                    for (int i = 0; i < rows.length() && shown < MAX_ROWS; i++) {
                        JSONObject r = rows.optJSONObject(i);
                        if (r == null) continue;
                        rv.setViewVisibility(ROW[shown], View.VISIBLE);
                        rv.setTextViewText(CUR[shown], r.optString("c"));
                        rv.setTextViewText(SPENT[shown], sameDay ? r.optString("s") : r.optString("z"));
                        rv.setTextViewText(BAL[shown], sameDay ? r.optString("i") : r.optString("iz"));
                        shown++;
                    }
                }
            }
        } catch (Exception ignored) {}

        for (int i = listed; i < E_ROW.length; i++) rv.setViewVisibility(E_ROW[i], View.GONE);
        if (more > 0) {
            rv.setViewVisibility(R.id.ent_more, View.VISIBLE);
            rv.setTextViewText(R.id.ent_more, "+" + more + " more");
        } else {
            rv.setViewVisibility(R.id.ent_more, View.GONE);
        }
        for (int i = shown; i < MAX_ROWS; i++) rv.setViewVisibility(ROW[i], View.GONE);
        rv.setViewVisibility(R.id.sum_empty, shown == 0 ? View.VISIBLE : View.GONE);
        return rv;
    }
}
