package com.myledger.app;

public class InvestmentWidget extends QuickAddWidget {
    @Override protected String type() { return "investment"; }
    @Override protected int layoutId() { return R.layout.widget_investment; }
    @Override protected int requestCode() { return 7103; }
}
